<!-- Sidebar Include -->
<?php include('include/sidebar.php')?>
		<div class="main">
			<!-- Top Header -->
		<?php include('include/top_header.php')?>
		<!-- Top Header -->

	<main class="content">
		<div class="container-fluid p-0">
        <h1 class="h3 mb-3">Add a New User</h1>

			<div class="row">
				<div class="col-12">
					<div class="card">
						<div class="card-body">
                            <form action="" method="POST">
                                <div class="row">
                                    <div class="col-md-12">
                                        <input type="text" class="form-control mb-3" placeholder="Name" name="username">

                                        <input type="text" class="form-control mb-3" placeholder="Email" name="email">

                                        <input type="text" class="form-control mb-3" placeholder="Password" name="password">

                                        <input type="text" class="form-control mb-3" placeholder="Re Type Password" name="re_password">
                                    </div>

                                        <div class="col-md-12">
                                            <select name="user_role" class="form-control mb-3" id="">
                                                <option value="3">Select Role</option>
                                                <option value="1">Admin</option>
                                                <option value="2">Editor</option>
                                                <option value="3">Author</option>
                                            </select>

                                            <select name="user_status" class="form-control  mb-3"   id="">
                                                <option value="2">Select Status</option>
                                                <option value="1">Active</option>
                                                <option value="2">Inactive</option>
                                            </select>
                                                <input type="text" class="form-control mb-3" placeholder="Department" name="department">

                                                <input type="submit" name="submit" value="Register New Member" class="btn btn-sm btn-primary">
                                        </div>
                                </div>
                                <?php
                                    if(isset($_POST['submit'])){
                                        $name           = $_POST['username'];
                                        $email          = $_POST['email'];
                                        $user_role      = $_POST['user_role'];
                                        $user_status    = $_POST['user_status'];
                                        $department     = $_POST['department'];

                                        
                                        $password       = $_POST['password'];
                                        $re_password    = $_POST['re_password'];

                                        if($password    == $re_password){
                                            $final_pass = $password;
                                            $add_user   = "INSERT INTO user (user_name, user_email, password, user_role, user_status, join_date, department) VALUES ('$name', '$email', '$final_pass' '$user_role', '$user_status', 
                                            now(), '$department')";
                                            
                                            echo $add_user;
                                            
                                            $sql = mysqli_query($db, $add_user);
                                            if($sql){
                                                echo "Registered Successfully";
                                            }else{
                                                mysqli_error($db);
                                            }

                                        }else{
                                            echo "<div class='alert alert-danger'>Password Wrong</div>";
                                        }

                                    }
                                ?>
                            </form>
                        </div>
					</div>
				</div>
			</div>
		</div>
	</main>

<!-- Footer -->
<?php include('include/footer.php')?>
<!-- Footer -->