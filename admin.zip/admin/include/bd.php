<?php
    $db = mysqli_connect("localhost", "root", "", "ssb-465");
    if($db){
        // echo "Connected Successfully";
    }else{
        mysqli_error($db);
    }
?>