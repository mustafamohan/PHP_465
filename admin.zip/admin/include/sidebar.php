<?php include('header.php')?>
	<div class="wrapper">
		<nav id="sidebar" class="sidebar js-sidebar">
			<div class="sidebar-content js-simplebar">
				<a class="sidebar-brand" href="index.html">
          <span class="align-middle">Food Blog</span>
        	</a>

				<ul class="sidebar-nav">
					<li class="sidebar-header">
						Pages
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="dashboard.php">
                            <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
                        </a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="profile.php">
                            <i class="align-middle" data-feather="user"></i> <span class="align-middle">Profile</span>
                        </a>
                    </li>
                    <li class="nav-item dropdown sidebar-item">
                        <a class="nav-link dropdown-toggle sidebar-link" href="#" role="button"  data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="align-middle" data-feather="users"></i> <span class="align-middle">Users</span>
                        </a>
                        <ul class="dropdown-menu">
                            <li class="sidebar-item"><a class="dropdown-item" href="user.php">All User</a></li>
                            <li class="sidebar-item"><a class="dropdown-item" href="add_user.php">Add User</a></li>
                        </ul>
                    </li>
				</ul>
			</div>
		</nav>