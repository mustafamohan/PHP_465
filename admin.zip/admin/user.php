<!-- Sidebar Include -->
<?php include('include/sidebar.php')?>

		<div class="main">
			<!-- Top Header -->
		        <?php include('include/top_header.php');?>
		    <!-- Top Header -->

			<main class="content">
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">All Users</h1>

					<div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-body">
                                <table class="table table-dark table-striped">
                                        <thead>
                                            <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">First</th>
                                            <th scope="col">Last</th>
                                            <th scope="col">Handle</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                            <th scope="row">1</th>
                                            <td>Mark</td>
                                            <td>Otto</td>
                                            <td>@mdo</td>
                                            </tr>
                                            <tr>
                                            <th scope="row">2</th>
                                            <td>Jacob</td>
                                            <td>Thornton</td>
                                            <td>@fat</td>
                                            </tr>
                                            <tr>
                                            <th scope="row">3</th>
                                            <td colspan="2">Larry the Bird</td>
                                            <td>@twitter</td>
                                            </tr>
                                        </tbody>
                                </table>
								</div>
							</div>
						</div>
					</div>

				</div>
			</main>

<!-- Footer -->
<?php include('include/footer.php')?>
<!-- Footer -->